# Assignment: Crypto Market Dashboard - Spryntworks

## Objective
Build a high-performance, responsive React web application that serves as a real-time cryptocurrency price tracker.

## Functional Requirements
- **Data Integration**: Fetch top cryptocurrencies (min 10) from CoinGecko API.
- **Live Metrics**: Name, Symbol, Logo, Price (USD), 24h Change (Color-coded), Market Cap.
- **Search & Filter**: Client-side search bar for assets.
- **Responsive Layout**: Desktop, Tablet, and Mobile optimized using Tailwind CSS.

## Bonus Features to Include in Design
- **State Persistence**: Dark/Light mode toggle.
- **Auto-Polling**: Visual indicators for data refreshes.
- **Deep Insights**: Modal/Drawer for advanced metrics (24h High/Low, Circulating Supply).
- **UI/UX Polish**: Skeleton loaders, professional spacing, consistent design language.

## Design Goals
- AI-native, high-fidelity look.
- Professional, clean typography.
- Seamless digital experience.