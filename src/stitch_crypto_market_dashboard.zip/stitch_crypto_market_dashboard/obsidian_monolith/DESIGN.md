```markdown
# Design System Specification: Tactile Intelligence

## 1. Overview & Creative North Star

### The Creative North Star: "The Sovereign Lens"
This design system is built to evoke the precision of a high-end horological instrument fused with the atmospheric depth of a cinematic command console. We are moving away from the "SaaS-standard" layout of cards and sidebars. Instead, we treat the UI as a **Sovereign Lens**—a series of hyper-precise data points suspended within a deep, obsidian void.

To achieve an editorial feel, we prioritize **intentional asymmetry**. Large-scale serif typography should dominate branding and primary KPIs, while ultra-sharp, technical data is tucked away in disciplined, monospaced grids. The experience must feel exclusive, quiet, and profoundly authoritative.

---

## 2. Colors & Atmospheric Depth

The palette is rooted in the "Obsidian" spectrum—not a flat black, but a layered, translucent environment that feels infinite.

### The "No-Line" Rule
Standard 1px solid borders are strictly prohibited for defining sections. In this system, boundaries are created through **background shifts**. A section is defined by moving from `surface` to `surface_container_low`. If you need to separate a list item, do not draw a line; use a 4px vertical gap or a subtle shift to `surface_container_highest` on hover.

### Surface Hierarchy & Nesting
Depth is achieved through the physical stacking of glass layers.
- **Base Layer:** `surface` (#131313) – The infinite void.
- **Secondary Tier:** `surface_container_low` – Large layout regions.
- **Active Tier:** `surface_container_high` – Interactive glass cards.
- **Highlight Tier:** `surface_bright` – Use sparingly for small callouts or headers.

### The Glass & Gradient Rule
To provide "visual soul," use semi-transparent fills on all floating containers. 
- **Effect:** Background Blur (20px - 40px) + `surface_variant` at 40% opacity.
- **Signature Gradient:** For primary actions, transition from `primary_fixed_dim` (#00e639) to `primary_container` (#00ff41) at a 135° angle. This creates a "Phosphor Glow" that feels energized rather than static.

---

## 3. Typography: The High-Low Contrast

The typographic identity relies on the tension between the organic (Serif) and the technical (Geometric Grotesk/Monospace style).

*   **The Authority (Display/Headline):** Use `notoSerif`. For high-value crypto balances or section titles, use `display-lg`. This serif should feel oversized and "editorial," as if it were on the cover of a luxury magazine.
*   **The Precision (Body/Labels):** Use `spaceGrotesk`. This is your technical workhorse. For data tables and labels, use `label-md` with increased letter-spacing (0.05rem) to achieve that "command console" look.
*   **Hierarchy Tip:** Never pair two fonts of the same size. If the Noto Serif headline is 2.25rem, the supporting Space Grotesk data should be significantly smaller (1rem or less) to emphasize the contrast between "The Story" and "The Data."

---

## 4. Elevation & Depth: Tonal Layering

We do not use traditional drop shadows. We use **Ambient Glows** and **Tonal Stacking**.

### The Layering Principle
Instead of a shadow, place a `surface_container_lowest` element inside a `surface_container_low` parent. This "sunken" effect creates a sophisticated hierarchy without adding visual clutter.

### Ghost Borders & Inner Glows
While 100% opaque borders are banned, "Ghost Borders" are permitted for interactive elements.
- **The Ghost Border:** 1px solid `outline_variant` (#3b4b37) at 20% opacity. 
- **The Edge Glow:** For "Obsidian Glass" cards, apply a 1px top-border using `primary_fixed` at 10% opacity. This mimics light catching the top edge of a physical sheet of glass.

### Ambient Shadows
If a modal must float, use a shadow color tinted with `surface_tint` (#00e639). 
- **Spec:** `0px 24px 48px rgba(0, 230, 57, 0.04)`. This creates a faint green atmospheric bloom rather than a "dirty" grey shadow.

---

## 5. Components

### Buttons (The "Tactile" Trigger)
- **Primary:** Gradient fill (`primary_fixed_dim` to `primary_container`). Black text (`on_primary_fixed`). No border. High-gloss finish.
- **Secondary:** Ghost Border (20% opacity) with `spaceGrotesk` uppercase text.
- **Interaction:** On hover, increase the `backdrop-blur` of the button and add a 2px outer glow using `surface_tint`.

### Glass Cards
- **Structure:** `surface_container_low` with 40% opacity.
- **Texture:** Apply a subtle noise/grain SVG filter (opacity 3%) to the background to break the digital smoothness and make it feel like "Obsidian Glass."
- **Nesting:** Do not use dividers inside cards. Use `title-sm` for headers and `body-sm` for content, separated by `1.5rem` of vertical space.

### Data Inputs
- **Style:** Underline only. Use `outline` (#84967e) at 30% opacity for the default state.
- **Active State:** The underline transitions to `secondary_container` (#00e3fd) with a 4px soft glow beneath the line.

### Chips & Tags
- **Filter Chips:** Use `full` roundedness. Background: `surface_container_highest`. Text: `label-md`.
- **Selection:** When selected, the chip should take on the `secondary_fixed_dim` color with `on_secondary_fixed` text.

---

## 6. Do's and Don'ts

### Do:
- **Embrace Negative Space:** Allow data to breathe. A single "Phosphor Green" number in a sea of Obsidian is more powerful than a crowded dashboard.
- **Use Intentional Asymmetry:** Align primary branding to the far left and technical data to the far right, leaving the center open for cinematic "hero" visuals.
- **Layer Textures:** Combine backdrop blur, grain, and thin "Ghost Borders" to create the illusion of a physical object.

### Don't:
- **Don't use 100% White:** Use `on_surface` (#e5e2e1) for text. Pure white (#FFFFFF) is too harsh for the "Obsidian" environment and breaks the cinematic tone.
- **Don't use Dividers:** If you feel the urge to add a line between list items, increase the padding or change the background tone of every other item instead.
- **Don't use Standard Curves:** Stick to the `sm` (0.125rem) or `none` roundedness for technical data containers to keep them feeling "sharp." Use `xl` (0.75rem) only for large "Hero" glass cards.

---

## 7. Motion & Interaction (Director's Note)
Transitions should be slow and "heavy." When a glass card appears, use a subtle "fade and scale" (scale from 98% to 100%) with a long duration (400ms) to mimic the weight of thick glass. The "Phosphor Green" accents should pulse slightly, like a heartbeat or a functioning power-on light on a high-end amplifier.```