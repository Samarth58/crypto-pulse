# Design System Strategy: The Kinetic Vault

## 1. Overview & Creative North Star
In an industry defined by volatility and noise, this design system establishes a **"Kinetic Vault"** aesthetic. Our goal is to move beyond the static, boxy layouts of traditional fintech and create a high-performance environment that feels both immutable and fluid. 

The "Kinetic Vault" treats data as a premium asset. We achieve an "AI-native" feel through **intentional asymmetry**, where the layout breathes and shifts based on data priority. We avoid the "template" look by utilizing heavy typographic contrasts and a layered "glass" architecture that suggests depth and sophisticated processing power. This is not just a dashboard; it is a high-fidelity command center.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule
Our palette is rooted in deep obsidian tones (`surface: #0b1326`) contrasted against a high-energy "Electric Indigo" (`primary: #c0c1ff`).

### The "No-Line" Rule
To achieve a premium, editorial feel, **standard 1px solid borders are strictly prohibited for sectioning.** We do not use lines to separate ideas. Instead, boundaries are defined by:
- **Background Shifts:** Use `surface-container-low` to sit on top of the base `surface`.
- **Tonal Transitions:** Define areas using a subtle shift from `surface-container` to `surface-container-high`.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Hierarchy is established by "stacking" container tiers:
1.  **Base Layer:** `surface` (#0b1326) – The canvas.
2.  **Sectioning:** `surface-container-low` (#131b2e) – For large layout regions.
3.  **Content Cards:** `surface-container` (#171f33) – For primary data units.
4.  **Interaction States:** `surface-container-highest` (#2d3449) – For active or hovered states.

### The "Glass & Gradient" Rule
To inject "soul" into the UI, main CTAs and Hero sections should utilize a **Signature Texture**. Instead of flat fills, use a linear gradient: `primary` (#c0c1ff) to `primary_container` (#8083ff). For floating overlays, use a backdrop-blur (20px+) with a semi-transparent `surface_bright` at 60% opacity to create a "frosted glass" effect.

---

## 3. Typography: The Editorial Voice
We use a dual-font strategy to balance "High-Tech" with "High-Trust."

*   **The Voice (Display & Headlines):** **Space Grotesk.** This font brings an architectural, slightly "brutalist" edge that feels innovative and AI-native. Use `display-lg` (3.5rem) for portfolio totals to command authority.
*   **The Logic (Body & Labels):** **Inter.** Selected for its extreme legibility at small sizes. All numerical price data must use Inter’s **tabular lining (monospace)** features to ensure that decimals align perfectly in vertical columns, allowing the eye to scan market movements instantly.

**Hierarchy Tip:** Pair a `headline-sm` in Space Grotesk with a `label-md` in Inter (All Caps, 0.05em tracking) for a sophisticated, editorial header style.

---

## 4. Elevation & Depth
We eschew traditional drop shadows in favor of **Tonal Layering**.

*   **The Layering Principle:** Place a `surface-container-lowest` card inside a `surface-container-low` section. This "negative" nesting creates a soft, natural sense of depth without the clutter of shadows.
*   **Ambient Shadows:** If an element must float (e.g., a dropdown or modal), use a shadow with a 32px blur, 0px offset, and 6% opacity. The shadow color should be tinted with `primary` to simulate light refracting through a digital lens.
*   **The "Ghost Border" Fallback:** For accessibility in high-density tables, use a "Ghost Border." This is the `outline-variant` (#464554) at **12% opacity**. It provides a hint of structure without breaking the seamless "No-Line" philosophy.

---

## 5. Components

### Buttons & Interaction
*   **Primary Action**: Gradient fill (`primary` to `primary_container`) with `on_primary` text. Use `xl` (0.75rem) roundedness for a modern, approachable feel.
*   **Secondary/Glass Action**: `surface_variant` at 40% opacity with a `backdrop-blur`. This allows the dashboard data to peek through the UI.

### The "Market-Flow" Card
Cards should never have borders. Use `surface-container` and a `DEFAULT` (0.25rem) radius for a sharp, professional look. For "AI-suggested" insights, use a subtle glow effect using the `surface_tint` at 5% opacity.

### Data Tables & Lists
*   **No Dividers:** Forbid the use of horizontal lines. Use **vertical white space** (16px - 24px) to separate rows. 
*   **Zebra Tonalities:** Instead of lines, use a alternating background of `surface` and `surface-container-lowest` to guide the eye across high-density price data.
*   **Semantic Indicators:** Growth (Emerald `tertiary`) and Loss (Rose `error`) should be used for text and small "micro-sparklines," never for large background fills.

### Input Fields
Inputs should feel "sunken" into the interface. Use `surface-container-lowest` with a "Ghost Border" that illuminates to a 1px `primary` border only upon focus.

---

## 6. Do’s and Don’ts

### Do:
*   **Use Monospace for Numbers:** Ensure all currency and percentage values align vertically for rapid scanning.
*   **Embrace Negative Space:** Allow for "asymmetric breathing room." A dense data table should be balanced by a high-contrast, large-scale `display-md` headline.
*   **Layer via Color:** Use the `surface-container` tiers to build depth.

### Don’t:
*   **Don't Use Pure Black:** Always use `surface` (#0b1326) to maintain a sophisticated, deep-navy "midnight" feel.
*   **Don't Use Standard Borders:** Avoid the "Excel-sheet" look. If you think you need a line, try using a 4px gap or a tonal shift first.
*   **Don't Over-Saturate:** Keep `primary` and `secondary` for actions and highlights. The data (the "Vault content") should remain the hero.
*   **Don't Use Default Shadows:** Never use high-opacity, grey shadows. They make the UI look "dirty" rather than "deep."